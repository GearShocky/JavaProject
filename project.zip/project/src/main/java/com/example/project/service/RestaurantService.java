package com.example.project.service;

import com.example.project.dto.OrderDTO;
import com.example.project.entity.Order;
import com.example.project.repository.OrdersRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.Collectors;

@Service
public class RestaurantService {

    private final OrdersRepository repository;

    @Autowired
    public RestaurantService(OrdersRepository repository) {
        this.repository = repository;
    }

    public List<OrderDTO> getAllOrders() {
        return repository
                .findAll()
                .stream()
                .map(order -> order.mapTo(order))
                .collect(Collectors.toList());
    }

    public Boolean addOrder(OrderDTO orderDTO) {
        try {
            repository.save(orderDTO.mapTo(orderDTO));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Boolean updateOrder(Long id, Integer newCount) {
        Order existingOrder = repository
                .findById(id)
                .orElseThrow(NoSuchElementException::new);
        existingOrder.setCount(newCount);
        try {
            repository.save(existingOrder);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public Boolean deleteOrder(Long id) {
        repository.deleteById(id);
        return true;
    }
}
