package com.example.project.dto;

import com.example.project.entity.Order;
import com.example.project.base.MapTo;
import lombok.Getter;

import java.util.Objects;

@Getter
public class OrderDTO implements MapTo<Order, OrderDTO> {
    private final Long id;
    private String name;
    private String description;
    private int count;

    public OrderDTO(Long id, String name, String description, Integer count) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.count = count;
    }

    @Override
    public Order mapTo(OrderDTO orderDTO) {
        return new Order(
                name = orderDTO.getName(),
                description = orderDTO.getDescription(),
                count = orderDTO.getCount()
        );
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        OrderDTO orderDTO = (OrderDTO) o;
        return Objects.equals(id, orderDTO.id) && Objects.equals(name, orderDTO.name) && Objects.equals(description, orderDTO.description) && Objects.equals(count, orderDTO.count);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, name, description, count);
    }
}
