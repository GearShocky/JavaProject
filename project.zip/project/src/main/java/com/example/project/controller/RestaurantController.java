package com.example.project.controller;

import com.example.project.dto.OrderDTO;
import com.example.project.service.RestaurantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/kair/restaurant")
public class RestaurantController {

    private final RestaurantService service;

    @Autowired
    public RestaurantController(RestaurantService service) {
        this.service = service;
    }

    @GetMapping
    public List<OrderDTO> getAllOrders() {
        return service.getAllOrders();
    }

    @PostMapping
    public Boolean addOrder(@RequestBody OrderDTO orderDTO) {
        return service.addOrder(orderDTO);
    }

    @PutMapping("/{id}")
    public Boolean updateOrder(
            @PathVariable Long id,
            @RequestParam Integer count
    ) {
        return service.updateOrder(id, count);
    }

    @DeleteMapping("/{id}")
    public Boolean deleteOrder(@PathVariable Long id) {
        return service.deleteOrder(id);
    }
}
