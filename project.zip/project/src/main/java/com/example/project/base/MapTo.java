package com.example.project.base;

public interface MapTo<T, U> {

    T mapTo(U u);

}
