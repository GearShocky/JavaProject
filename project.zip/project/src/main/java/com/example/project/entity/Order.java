package com.example.project.entity;

import com.example.project.dto.OrderDTO;
import com.example.project.base.MapTo;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Entity
@Table(name = "orders")
@NoArgsConstructor
public class Order implements MapTo<OrderDTO, Order> {
    @Id
    @Setter
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private String description;
    @Setter
    private int count;

    public Order(String name, String description, Integer count) {
        this.name = name;
        this.description = description;
        this.count = count;
    }

    @Override
    public OrderDTO mapTo(Order order) {
        return new OrderDTO(
                id = order.getId(),
                name = order.getName(),
                description = order.getDescription(),
                count = order.getCount()
        );
    }
}
