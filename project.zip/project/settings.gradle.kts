rootProject.name = "project"
